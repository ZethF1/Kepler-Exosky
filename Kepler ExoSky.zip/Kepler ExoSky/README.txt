We are Kepler Koders, a team from Mazatlán, Mexico, consisting of Diego Gonzalez, Rodrigo Rochin, and Juan Francisco González. 
As high school students, this is our very first hackathon, and we have chosen to take on the ExoSky Challenge.

----------------------------------------------------------------------------------------------------------------------------
Step 1: Open your compiler and in the terminal run the following command to install the necessary dependencies:
pip install streamlit matplotlib numpy astroquery astropy

Step 2: Once the installation is complete, click extract all from the zip file. 

Step 3: Run the file run.bat. Trust the program, and when prompted, copy the local address provided and paste it into your browser to access the app.